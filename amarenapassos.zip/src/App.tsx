import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  IceCream, 
  X, 
  ShoppingBag, 
  ShoppingCart,
  MessageCircle, 
  Settings,
  Trash2,
  Edit,
  Check,
  Copy,
  CreditCard,
  QrCode,
  Printer,
  LayoutDashboard,
  Package,
  History,
  LogOut,
  ChevronLeft,
  MapPin,
  Instagram,
  CupSoda,
  Soup,
  Upload,
  Sliders
} from 'lucide-react';
import axios from 'axios';

// --- Types ---
interface Product {
  id: string;
  name: string;
  category: 'acai' | 'sorvete' | 'milkshake' | 'picole' | 'promos' | 'potes' | 'addon';
  price: number;
  description: string;
  image?: string;
  active?: boolean;
}

interface Order {
  id: string;
  items: { name: string; price: number; quantity: number }[];
  total: number;
  paymentMethod: string;
  status: string;
  createdAt: string;
}

// --- Custom Icons ---
const AcaiBowlIcon = ({ size = 24 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    {/* Base Bowl */}
    <path d="M4 12c0 4.418 3.582 8 8 8s8-3.582 8-8" fill="currentColor" fillOpacity="0.2" />
    <path d="M3 11h18" />
    <path d="M4 11c0 4.418 3.582 8 8 8s8-3.582 8-8" />
    <path d="M8 19h8" />
    {/* Creamy Acai / Ice Cream Top */}
    <path d="M6 11c0-2 1.5-3.5 3-4s2-2 4-2 2.5 1.5 4 2 3 2 3 4" fill="currentColor" fillOpacity="0.3" />
    {/* Fruits/Toppings (strawberries/banana slices) */}
    <circle cx="8.5" cy="8.5" r="1" fill="currentColor" />
    <circle cx="12" cy="6" r="1.5" fill="currentColor" />
    <circle cx="15.5" cy="8.5" r="1" fill="currentColor" />
    <path d="M12 7.5v3.5" />
  </svg>
);

const PopsicleBittenIcon = ({ size = 24 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 14V6c0-3.3-2.7-6-6-6S5 2.7 5 6v8c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2Z" />
    <path d="M11 16v4" />
    <path d="M17 6a3 3 0 0 0-3-3" />
  </svg>
);

// --- Components ---

const Logo = ({ className = "" }: { className?: string }) => (
  <div className={`flex items-center w-full gap-4 ${className} group cursor-default select-none`}>
    <div className="w-28 h-28 flex-shrink-0 bg-white rounded-full flex items-center justify-center shadow-[0_8px_25px_rgba(0,0,0,0.2)] overflow-hidden border-[4px] border-white transform -rotate-6 transition-all group-hover:rotate-0 group-hover:scale-105 z-10">
       <div className="relative w-full h-full bg-white flex items-center justify-center">
          {/* Official Brand Logo Image */}
          <img 
            src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAGAAQ8DASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD36jNJ3pTQAZo7UetJQAtGeaBR3oASlo7UUAGfakpRRQAfhR3pKXvQAZooo7UAGfaj8KKKAEpc+1JS0AH4UdqKSgBaM80Ud6ACiiigA70Ud6M0AFHek7UtABmiijtQAfhSUtFAB2oFJS96ACg9aKDQAUUUUAFJ3paO9AB2oo7UUAHeiiigAo70cUd6ADNFHajtQAZoo4ooAKKO1BoAM0dBRxR2oAKKKKACijsaO1ABmijjNFAB2o70cYooAO9AoFHFABR3oo4oAKBR2ooAKOaMc0HrQAUlLSUALmjmgUd6ACijtRQAUlLikoAXNHNGKP5UAGaSil9qADNFJS0AGeKKSjtQAuaO1FHagAo5pKWgA60UYpKAFzzRRikoAXNHejFFABR0pKWgAo6UUUAFHeigUAH40HrRR3oAKKPwo7UAHvmjvRR3oAM0UdqKADvRR3o9aACjvR+FHegAo7UUUAFFFHrQAUfWij8KACjtRR2oAKKKO9AB1ooo7UAHejvR3ozQAUd6PwooAO9HSgUfhQAUd6KKACjNH4UUAGaO9H5UUAJRS0lAC5ooo70AHaijFFAB3ooFFABmijFHegApKXHFHagAooooASlooNABR2oo7UAJS0UUAHaj8aMUUAFFFFABmiiigAo7UYooAPxo5zRRQAUCjFFABxiijmg9aACijrR2oAKM0c0DrQAUUc0UAHeijmigAoHWjmjvQAUZo5ooAKKOaKACijtRQAUdqKO1ABSUpo70AFHpR60dqADvRRzRQAUd6O1GeaAEopeaKACiijvQAlLRzR6UAGaKKDQAUlL60dqAEpe9AoHWgA7UlLRQAlFKKKAEpaOtHegBKWijtQAUUUUAJRS0fWgAo7UUdqAEopaKADtSUtHagBO9LRSd6AFpKXtRQAlFLRQAlFLRQAlKKKBQAfhQetFFAAO9FFFABRRSUAL2oo7UUAHej8KPxooAO1HeijPNABR+FH40UAFHrR+NFAB2oo7UUAFHaijt1oAD0oo/GjvQAUUUfjQAd6KO/WigA7Ud6O1HegAo/Cj8aSgBaPWiigAoo/GgUAFHeig0AFJS0dqACjvRR0NABRR2ooAKPWiigA7Ud6KO9ABSUtHagAzRRR60AHajNJWT4g8RWHhyyWe8Ls8jbIYYxl5G9AP6/wCIobsTKUYLmk7I16O1YnhzWb7W4Jp7vR5tNVWAjEzZaQeuCoIrb7UBCanHmWwUfhSfWl5zQUGaKO1HagA70UfWigA7UUdqDQAUlKKKACiig0AFA60UUAFHekooAUd6KO1JQAuaKTvS0AGTiijtRQAUc0UlAC9qOho7VxNzear4wvZrPRrlrDRoXMc9+g+edh1WL0A/vf8A6im7GdSpydLt9Dpr7XtJ0x9l9qVrbyHkJJKA35daqxeLvD07hU1qy3HgBpQufzqnY+APDdkmG09bmQ8tJcsZGY+p7fkBTb/4feGr6MqNOW2bGA9sxQj8Oh/EGl7xi3ibXSXpr+Z06urqGRgykcEHINL0rya70fxF8PJTfaVdPeaSDukiYcKP9te3+8v44Fde3iuPU/Aeo61pp2Tw20hKHkxSBSefXHX3FLntuXhazrVFRkuWfZ/5mymuWMmpnToZJJrhTiTyomdIjjOHcDap9ic1g6be6VeeLJbm9uoTqTgx2Fu5+ZIFyNyj+85DN67dtaHgqGCHwZpJhAzJbJLIe7SMMsSe5yTXEfFrTbXT2sNctP3F+0u1mTjdsXcr49V2gZ9CPQVnObjT5z2KGAo4jGfVm2t0v8S2b7Ly19T1ajnFRwMzwRu4wzKCR6Gn1uecLmiisLUdenS5ez0fTpNRu0IEhDCOGE+jue+OdoyfXGRQ3YmU1FXZu80c1yLt8QCS6p4eC9o8yk4+tMtfG0lpfx6f4m01tKnk4jn374JP+Bdv1x3IqeZGP1iKfvJr1R2PejmkyDyOlLVHQHajvRRQAUc0lLQAUUUd6ACgZpKUUAFBo/Cg0AHNJS0dqACk70tGaADtSUvaigA70UVV1G9GnadcXjQSzLBGZDHCAXYDk4BIyaG7DinJpIra+LiXSJbW0YrcXRFurjqgY4Zh7qu5vwq3Y2VvptlBZWsYjghQIijsBXO2+seI9YiinsdDtrS3cB4pr+5ySpH3giA9j3IrL1m91211/RNJbV2nuL2YmeKygWFUgHVstuYEdQc87SPSsnUS1sdVPL5SqNOSUrPrfRK72ul82jvQc9KO1eV+ANYj0r+35729nayF6sNvGd0rPIWkJ2qMksRgnA7EmvRNK13T9aWUWUpaSEhZoZI2jkjJ6blYAjPanTqqaT6lYzA1MNUlHdK2ttNUv8xzatpzao2kvcx/bDGH8h+CynPTPDdD0rjLTR4/DHj5bGBc6TrkMieSR8qOqliPpjOPZvauq17wxpniKFFvoSJY/wDVTxnbJGfY/wBDkViJ4X8TWLKtj4raSFD8iXlssjL/AMDOT/KnK541aNRzT5b2d01v+NjIHhzxn4VaS28M3cF3pZYtFBcY3RZOSOcfz59KxZraZNeg1Hx1qsU80DAw6dbESyM2chdqgKoyB1+9gAmuxk8KeJNQOzU/Fs3kHrHaQCIn/gQP8wa1dD8H6N4fIks7XdcY5uJjvkP49B+AFZexT9PU9d5zjZp8kIxk95tLm/Dq++hljVvGOs86ZpEGmWx5E2ouS5Hsg+6fqDSr4c8WyfPP4yZW/uxWSYH6j+VdjSZzxW3L3PM+rp/HJv52/KxyyWXjDTE3LqdnrKDkxTw/Z3I9FdcjP1Fa+i6la6hassEDW0kDeXNayLteF+uCPfqCODnNadZk9l5ev2uoQqwaRGt59vRlwWUn/dIIH++adrbFKDg1yvTz1NPtVDV9Js9b02WxvY98Ug691PZgexFX6O3SmayipKz2OG8A6ldW89/4X1GTdc6a2IWPVos4H4DKkezAdq7mvPImVfjXMIcc2mJseuwH+i126anaSXRt0lzKDtI2nGfTOMZ/HsamO1jlwsrQcG9m19xc7Ud6KO9UdYlFLRQAelFFBoAKBR2ooAPajiig9aACiikoAXvRR36UAUAHaj8aKKACkxnOaWigCvc3Nvp9lJcTMsVvAhZm6BVArmfD1rI5vfFmoxGO7vIyYI3GDb2yjKr7E/ePvWT4n8U6Vd+IbfSLy4K6Vbyb7gLC8n2qZSNsS7QchWwW9wBWj4n8RTN4T1OSHSdQihe1dRczBIgu4bQdrNv7/wB2sHUi232PWp4StCEY2s6ltXppfbXq938vM5nwD4eu9U8GreW1/wDYr0ag88E5iEg/1XlnKnGerfpWrFqUWg+PLj+0L555Y9JggkKR5e5n38EIuSWI7DoD7ZrovA1kNO8EaXEy7C0Ambdxgvlzn/vqub8C2qa74m1rxbIu5HnaCzJGPlAALc/7IUf99Cs4x5VBLf8A4B2VcQqtXE1KnwK6W19ZaK9vJvy3sdVpPim01S+msXtruwvYUEpt7xAjtH/fGCQR+NW5dd0qGxubw6hbtBaqWmaOQPsx6gZOfauH/s1PGHxP1CadS2naVElq4ViBM3J2HHVclsj/AGRng0eJtL0KPxbpthBaW9tEbSd9TMCiNVttuAXx6MBg9iB7VftJWv52OZ4LDurGF2m4qTS1tpe1/Nbdm1ub9j4j1jXLc3uj6NELEkiOW+uTE02O6qqNge5NO/4S13Q2f9nvFrXnrb/Y5ZBtDMrMG3jqm1WOQM8YxmsnQPGVnZ6Tb28Wlaw2kWkYiGpy242bF4DED+HHcDjuOtSeGb6HxN401rVIog9jBHDbQSMOHZSzbh+fHsRRGpe1nqwqYRQ9pKdK0Y7avukk9d9dVo/QzT4s1/TPEOuaPfTwXVysKGxKQiNfNcxqgAznGZB1J+6earXlpDpmk6jeRSaiNZsJURdUaYn7ZcEjMYTdyuTjbjGPxqxd2ou/jnbjAxBbrM2fUIwH6la1fHUOnaHp83iKLSrZ9SBCLdMOY3PCuR0Yj1PoKzs2pNva5288IVaMIRs5xi3ayu9rPbR2d91rs3Y1r/xppOm366dI89zqG3L29nC0rL65A6fTrWtpup2mr2SXdnJvibI5UqQQcEEHkEHtXnvhNb3S/D2zR9GvLjW7wb7i8vYjDGjE5wzPhnAz/DnJye9Z3i3TbjwfpGh3H9ozNfi8lluZ4mKGQvh36Y4+QD/9dWq0kuZrQ5f7NozqqhCVpXsr63snd26K9rXdz1e5v7Oy2farqCDecJ5sgXcfQZ61V1bXtN0SBJb+6WLzDtjQAs8h9FUZJ/CvMvGlpI/hv+09TthJrOr3KR20RGTaRA7lRfcjAb1LGugvdDsvD2raFr+pajbpDYWi2couiSWKodrR4HLZzx6ZNV7WTbSXYzWX0YxhKc22+ZWS3aS0T13el7EenGw0fxbe+IdTlv4Evxthe7s2jSIMRwz5IHRQN23iurh0VUvPO84GPcGC7ecDaQM56AovQc45rM1PxX4e1Hwhqd5FeQXdqsDJJH0YlgQqlTggk9M1peE/OPhHSDOWMv2OLcW6/dHX3qoyXNZa9TzqmBhTpc/I4tSaafffrr6+qNntR3oorUwAUlLRigAoooNABQKMcUUAHFH1o5ooABRiiigA+lJ3paM0AHakpaQ0ARrcQvO8CyoZUGWQMCyg9Miud1DU5tdvJtF0WZkWNtl9fx9IPVEPQyH/AMd6nnis7SvBmo2q3EM19BCLiV2uby2DfarpSxIUsf8AVjnB259iK66w0+00qyjs7G3jgt4xhY0GAP8A6/vWa5pb6HbJUKEm4S530009X+i+/sQ2uiadZWtjbwWkaR2Ofs/GTGSCCQeuSCcnvmuf+I0bXmg2ukIGLalfQ22V6qM7ifw212FVLzTrW+mtpp490lrJ5kLbiNjYxng88djTnC8XFGeHxDp141p6ta/PdfjqU/EFnez+GL2x0rYtzJAYYtzlAoPBwR0IGce+OlQeGNKk8P8Ag+0shDm4hgLyRqwOZTlmAPTqSPStCPU4ftgsrj9xdMMoj9JB6o3Rvp1HcDIq9T5VzcxmsTJ0fYra9/naxw2ibvBHgefUNWiJ1G4me4niQ5aSZzhUGM8njp7mq134P1K88Faq0rLJ4g1TZPcchR8pBEKnsABjk9e+K0/FbwL4s8Ki/YLYefK3zY2eeFHlbs/Vse9WLnxTd2eu3+nS6RIUhtWubWRJR/pO0LuXB+6ctj8KxtH4XstPwPUdetFfWIfFL336RlpFeStdpdLdijqY17xHph0ew0ttGs5U8qe4vChYR4wUjRCc8cZJHH5ixoOg6p4avE06w+xy6IzmWSWXIuASuCOOG+YDn047Con8dlbVXj09XnSOaa4i88p5SRbdw+ZAS+HGFKj61ZbxkFM80mnsmnwXS28t00oG3coIO3GcfMoP1qlGPNe+p5bzaLpulGyi+lnv3u9br1siOHw7fJ8S7jxA3k/YntPJUbzv3YXtjpwe9avijQ18R+HLvS2cRtMoMbn+FwcqfpkVjweNpri4jt10iVJGjj3hmY+XJJHvVSQmMYIBJIIyeDg1Fpvji5nj0yO404vLcQQSzyQFiqeaSFIG0+mSCRjoCxFO0EnHuZvNeacJqWsbJadtjSi1rW1tkt5PDd018q7WcTRC3LdN2/du29/u59q5vXNM1LWfGvhvT9QjaaG2V7q5njiKwk7shBnrjYq+uG966rQfELazc3MEtp9klhAYRu5LlSSATlQMcdVLD3rdocOZWbOrDZhGL9rSglo116prr2ucv4s0K71S+0XULSOOdtOufNe3kk2CQHHQ4IyCo61zl5Io8bLf+Nora2s4bUtp8TEywht3zZO3Bk4zjHpjpXa634k0vw/B5moXSo5GUiX5pH+i/wBelcnpWs+IPGuqrNabtL0OB/mcAF5sH7oJHX1xwOeTxSnBN6bkQzdUbUWuZ2aVtJJN3euy83a9tDM17RLvxtqaahZ6QYdMso8J5yeTLe/MCyqDgqCAQCcdffj0PRNSbVLDzzpt5p4VzGsN3GEcgY5wCcDt+HpitKjvVQp8rvfc1xGNdanGk42UdtXp39b9/wBAo70UVocQd6Sl6UUAHcUUUGgBKUUUUAJS0UHrQAUUUdqACijvRQAdqKKKADvSetLSUALR3oo70AVb/T7TU7R7W9gWaFudrdiOhB6gjsRyK597XxJoJLadKNZsR0trp9twg9Fk6N/wLn3NdV2o7Umrmc6alrs+6OMm8V+GdaifStegazkP37XUYimMd93QexyK1tI8P+H7a2lOnwRTRXEflu7SmcOn93LE/L7dK0r7TLHU4fJvrSG4j6hZUDY+melcrc/DLRjMZ9OnvdNm7G3myP1yf1qeXW9ri9ti4QdNPmi+l7fhszo20DRmtorZtKsjBE++OM26FUb1AxwferD6dYywzwyWdu8Vw2+ZGiUiRuOWGOTwOvoK4r/hDPFdpkWXjGd17CcMcfmzVj6i3izSZxDfeNtLgc87JJsNj1x5eaOa26OaWIcF71Jr7v8AM9MbTbB75L1rO3N3Gu1JzEpdR6BsZA5NVm0nQ7EQTtY6fbi1yYXMSJ5OSSdpx8uSSePWuHtPDvijXLVZ08bpLAx4ezmZlPtldv5VMnwojuJPN1TXLu6k/vKgBx9WLUXb2Qe1qS1hS+9r/gmjceMfB3h5pnsfs8k8p3SCwhU+YeeSwwp6nvXPS+NPFPiqRrfw5pzW8OdrTKNxH1dsKvHbr6Guu0/4feG9PIYaeLh8feuWMn/jp+X9K6ZI1jQJGqqijAVRgD8KLSe4vYYippOSiu0f8zz7Q/hjEJ/t3iG6a+uWO5owxKk/7THl/wBB9a9Aihit4UihjWONBtVEUAKPQAdKf2o7VSSWx00cPToq0EFHejvRTNg7Ud6TtS96AAUlKKSgBaKPSj1oASlFHaigANFFBoAOxooooAKTFLikoAXtRiiigA70YopKAFoA5oo70AFJS8UlACmiisTXfFmkeHlIvroefjK28XzSH8Ow9zgUbEznGC5pOyNvtXn+hy2fhnxBrCeINlvc3Vy00F/OMRyxHooc8AjuOOvtTYvE/i3xKc6BpEVlZt0urvnI7EdvyDfWrS+FPFVyub7xhIpPVILcY/MFf5VDd9jinV9q1KnFu3W2n4tF6xmsL3xcl3obJLAbdxfT2/MMhyvlgkcM4+bpyBnPUV1XauMXw14rsyGs/FxlC/8ALO5tFIPsTkn8qsRa54h0vC69ovnRDrd6ZmVR9Y/v/iM/Smnbc1p1OT44tX+78LnV0VBaXltf2yXFpOk0TdHQ5HuPr7VPVHSmmroKO1FFAwoo70UAHajFFHQ0AJS4opKAFooooAKAKKBQAdqKSlPWgA7UUUZoAM0d6O9FACUtHakoAXPNJSij1oAKO9HajvQAUlLRQA2RS6MoJUkYBHUVxuhfDjTdMuWu9RlbVLotuDzr8oPqVyct7kn8K7TvR3pNJmc6MJtSkr2EGAAMcUUUtM0DvRRijtQBGsMSStKkaq7/AHmAwW+vrUn4UUd6ACj8KO1HagA70UUUAHajvSdqWgAzRQKKAD0o70Ud6ADNFHagdqAA0Gig0AHrRRRQAlLijFHegA7UUUUAHeiiigAzxQOtFHegAoo7UlAC0etFFABRRQaADvR2oo7UAJ2paPSg9aACiiigBKWjvRQAUd6O1HegBKWikoAX0ox1oooASloooAM0c0YoNABSUvrRQAUd6O9HegBO1LRjiigA5pKWigAoFGKO9ACUtHaigA5o9aKKAEpaTtS96ACjtRR2oADRSUvegAo7UdjR2oAO9FHejNABR3o7UGgBKBS0lAC96KKKACgUdqBQAcUUfhQaACjtRR2oAOlHeijvQAdqOKKKADiigUUAFHU0Ud6ACkpe1HagA70etFFAB2oooNABR2oo7UAJS8UUd6ADsaO1HajtQAUUUd6ADtRxmig0AFHFAooAKO9FFABQKO1AoAKDQaDQAUUUUAHNJjmlo70AJ2paO1FABSUtJQAtHeijvQAlFL2o7UAFFFFACUuKKO9ABR2oooATNLiijvQAZoxRR2oATvS4o/GigAo70dqO9AAKKKTtQAtFHpRQAlKOtFFABRRQaAD1ooo7UAFHeijvQAdqO9FFAB3ooooADR3pKXvQAUUYozxQAUUUUAFH1pKWgAo7UUdqACiijrQAdaKKKADvRRRQAUd6O1HegAFFFJQAvpR3oooAKBR2ozQAUUlKaACiiigApMc0tJQAvUUUUUAJRSiigAo4zRR3oAKSlooAKMUUd6AEope1BoAKMcUUdqAEpaKKADtRRR2oAO9FFJQAvaijtQaAEopaTtQAtHeijvQAlKKKPSgAoo70UAFFFAoAOtHeiigBO1LRRQAd6KKKACjvRRQAUc0Ue1ABRRRQAUUnaloAKO1FHagAooNHegAooo9KACjvRR3oAKO9FHegAHWiikoAWijvRQAlKKSlFABxRRQaAD1ooo7UAFHeijvQAdqKKKACijmjtQAlLxmijvQAUlLR2oAKKKKADtRR2ooAM0cYowaO1ABRRRQAdqO1GOKO1AB3pKWkoAXtRR2oNACUUtHagApKX0o70AAoFHaj0oA//9k=" 
            alt="Amarena Official Logo" 
            className="w-full h-full object-contain scale-[1.9] -translate-y-0.5"
          />
          {/* Clearer glossy overlay */}
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-white/30 pointer-events-none" />
       </div>
    </div>
    <div className="flex-1 text-center pr-[128px] text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)]">
       <h1 className="font-brand text-5xl leading-none tracking-tight text-white mb-1">Amarena</h1>
       <div className="flex items-center justify-center gap-3">
          <div className="h-[1px] w-4 bg-white/30" />
          <p className="text-amarena-green font-black text-[10px] tracking-[0.4em] uppercase">SORVETES</p>
          <div className="h-[1px] w-4 bg-white/30" />
       </div>
       <p className="text-white/50 text-[9px] font-bold tracking-widest uppercase mt-2">Passos — MG</p>
    </div>
  </div>
);

const Awning = () => (
  <div className="absolute bottom-0 left-0 right-0 flex translate-y-[50%] z-20 overflow-hidden pointer-events-none">
    {Array.from({ length: 15 }).map((_, i) => (
      <div 
        key={i} 
        className={`flex-1 h-8 rounded-b-full shadow-sm ${i % 2 === 0 ? 'bg-awning-mint' : 'bg-awning-cream'}`}
      />
    ))}
  </div>
);

const Button = ({ children, onClick, variant = 'primary', className = '', loading = false, disabled = false }: { children: React.ReactNode, onClick?: () => void, variant?: string, className?: string, loading?: boolean, disabled?: boolean }) => {
  const variants: Record<string, string> = {
    primary: 'bg-amarena-red text-white hover:bg-amarena-red/90',
    secondary: 'bg-amarena-green text-white hover:bg-amarena-green/90',
    purple: 'bg-amarena-purple text-white hover:bg-amarena-purple/90',
    orange: 'bg-amarena-orange text-white hover:bg-amarena-orange/90',
    outline: 'border-2 border-stone-200 text-stone-600 hover:bg-stone-50',
    ghost: 'text-stone-400 hover:text-amarena-red transition-colors'
  };

  return (
    <button 
      onClick={onClick}
      disabled={loading || disabled}
      className={`px-6 py-3 rounded-2xl font-semibold transition-all active:scale-95 flex items-center justify-center gap-2 ${variants[variant]} ${className} ${loading || disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {children}
    </button>
  );
};

// Ticket component for printing
const OrderTicket = ({ order }: { order: Order | null }) => {
  if (!order) return null;
  return (
    <div className="print-only p-8 text-black font-mono w-[80mm] mx-auto bg-white">
      <div className="text-center border-b border-black pb-4 mb-4">
        <h2 className="text-xl font-bold uppercase">Amarena Sorvetes</h2>
        <p className="text-xs uppercase">Passos - MG</p>
        <p className="text-xs mt-1">--------------------------------</p>
      </div>
      <div className="mb-4">
        <p className="text-sm font-bold uppercase">Pedido: #{order.id.slice(-6)}</p>
        <p className="text-xs uppercase">Data: {new Date(order.createdAt).toLocaleString('pt-BR')}</p>
        <p className="text-xs mt-1">--------------------------------</p>
      </div>
      <div className="mb-4">
        {order.items.map((item, idx) => (
          <div key={idx} className="flex justify-between text-xs items-start mb-1">
            <span className="flex-1 uppercase">{item.quantity}x {item.name}</span>
            <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
          </div>
        ))}
      </div>
      <div className="border-t border-black pt-4">
        <div className="flex justify-between font-bold text-sm">
          <span className="uppercase">Total</span>
          <span>R$ {order.total.toFixed(2)}</span>
        </div>
        <p className="text-xs mt-1 uppercase">Pagamento: {order.paymentMethod}</p>
      </div>
      <div className="text-center mt-8 text-[10px] uppercase">
        <p>Obrigado pela preferência!</p>
        <p>Amarena Sorvetes</p>
      </div>
    </div>
  );
};

// --- App ---

type AppSettings = {
  acai?: Record<string, number>;
  milkshake?: Record<string, number>;
  sundae?: Record<string, number>;
  acaiAddons?: string[];
  milkshakeAddons?: string[];
  sundaeAddons?: string[];
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'home' | 'sorvete' | 'picole' | 'potes' | 'acai' | 'promos' | 'milkshake' | 'whatsapp' | 'admin' | 'checkout' | 'success'>('home');
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(false);
  const [adminSection, setAdminSection] = useState<'dashboard' | 'products' | 'orders' | 'addons' | 'settings'>('dashboard');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(!!localStorage.getItem('amarena_admin_token'));
  
  // Login State
  const [adminUser, setAdminUser] = useState('');
  const [adminPass, setAdminPass] = useState('');

  // Checkout State
  const [cart, setCart] = useState<{ name: string, price: number, quantity: number }[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'pix' | null>(null);
  const [pixCopied, setPixCopied] = useState(false);
  const [lastOrderId, setLastOrderId] = useState<string | null>(null);
  const [printOrder, setPrintOrder] = useState<Order | null>(null);

  // Milkshake State
  const [selectedMilkshakeSize, setSelectedMilkshakeSize] = useState<string | null>(null);
  const [milkshakeFlavorInput, setMilkshakeFlavorInput] = useState('');
  const [milkshakeAddons, setMilkshakeAddons] = useState<string[]>([]);
  const [milkshakeCategory, setMilkshakeCategory] = useState<'milkshake' | 'sundae'>('milkshake');

  // Açaí selection state
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [selections, setSelections] = useState<string[]>([]);

  // Admin Hold State
  const [adminHoldProgress, setAdminHoldProgress] = useState(0);
  const holdTimerRef = React.useRef<NodeJS.Timeout | null>(null);

  // Product Management State
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);

  const [isDragging, setIsDragging] = useState(false);

  const productCategories = ['acai', 'sorvete', 'milkshake', 'picole', 'promos', 'potes', 'addon'] as const;

  const resizeImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 500;
          const MAX_HEIGHT = 500;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        };
      };
    });
  };

  const handleImageUpload = async (file: File) => {
    try {
      const resized = await resizeImage(file);
      setEditingProduct(prev => ({ ...prev, image: resized }));
    } catch (err) {
      console.error("Erro no processamento da imagem", err);
    }
  };

  const fetchProducts = async () => {
    try {
      const res = await axios.get('/api/products');
      setProducts(res.data);
    } catch (err) {
      console.error("Error fetching products:", err);
    }
  };

  const fetchOrders = async () => {
    try {
      const res = await axios.get('/api/admin/orders', {
        headers: { Authorization: `Bearer ${localStorage.getItem('amarena_admin_token')}` }
      });
      setOrders(res.data);
    } catch (err) {
      console.error("Error fetching orders:", err);
    }
  };

  const fetchSettings = async () => {
    try {
      const res = await axios.get('/api/settings');
      setSettings(res.data);
    } catch (err) {
      console.error("Error fetching settings:", err);
    }
  };

  useEffect(() => {
    let isMounted = true;

    const load = async () => {
      if (!isMounted) return;
      await fetchProducts();
      await fetchSettings();
      if (isAdminLoggedIn) {
        await fetchOrders();
      }
    };
    load();

    // Auto-refresh data to keep the store front and admin panel synced
    const intervalId = setInterval(() => {
      fetchProducts();
      if (isAdminLoggedIn) fetchOrders();
    }, 30000); // Every 30 seconds

    return () => { 
      isMounted = false; 
      clearInterval(intervalId);
    };
  }, [isAdminLoggedIn]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const res = await axios.post('/api/admin/login', { username: adminUser, password: adminPass });
      localStorage.setItem('amarena_admin_token', res.data.token);
      setIsAdminLoggedIn(true);
    } catch {
      alert("Credenciais incorretas!");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('amarena_admin_token');
    setIsAdminLoggedIn(false);
    setCurrentScreen('home');
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const token = localStorage.getItem('amarena_admin_token');
      
      let response;
      if (editingProduct?.id) {
        response = await axios.put(`/api/products/${editingProduct.id}`, editingProduct, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } else {
        response = await axios.post('/api/products', editingProduct, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }

      if (response.status === 200 || response.status === 201) {
        setEditingProduct(null);
        fetchProducts();
        alert("Produto salvo com sucesso!");
      } else {
        throw new Error(`Erro do servidor: ${response.status}`);
      }
    } catch (err: unknown) {
      console.error(err);
      const errorMessage = (err instanceof Error) ? err.message : "Erro desconhecido ao salvar produto.";
      alert(`Erro ao salvar produto: ${errorMessage}`);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Deseja realmente excluir este produto?")) return;
    try {
      const token = localStorage.getItem('amarena_admin_token');
      await axios.delete(`/api/products/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchProducts();
    } catch (err) {
      console.error(err);
      alert("Erro ao excluir produto.");
    }
  };

  const startAdminHold = () => {
    if (holdTimerRef.current) clearInterval(holdTimerRef.current);
    setAdminHoldProgress(0);
    const startTime = Date.now();
    holdTimerRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min((elapsed / 2000) * 100, 100);
      setAdminHoldProgress(progress);
      if (progress >= 100) {
        if (holdTimerRef.current) clearInterval(holdTimerRef.current);
        holdTimerRef.current = null;
        setCurrentScreen('admin');
        setAdminHoldProgress(0);
      }
    }, 50);
  };

  const cancelAdminHold = () => {
    if (holdTimerRef.current) {
      clearInterval(holdTimerRef.current);
      holdTimerRef.current = null;
    }
    setAdminHoldProgress(0);
  };

  const handlePrint = (order: Order) => {
    setPrintOrder(order);
    setTimeout(() => {
      window.print();
      // After print, user often wants to refresh or move back to orders
      setPrintOrder(null);
    }, 100);
  };

  const menuItems = [
    { id: 'sorvete', label: 'Sorvetes', icon: <IceCream />, color: 'bg-amarena-red' },
    { id: 'acai', label: 'Açaí', icon: <AcaiBowlIcon />, color: 'bg-amarena-purple' },
    { id: 'picole', label: 'Picolés', icon: <PopsicleBittenIcon />, color: 'bg-amarena-red' },
    { id: 'promos', label: 'Promoções', icon: <ShoppingBag />, color: 'bg-amarena-red' },
    { id: 'milkshake', label: 'Milkshake', icon: <CupSoda />, color: 'bg-amarena-red' },
    { id: 'whatsapp', label: 'WhatsApp', icon: <MessageCircle />, color: 'bg-amarena-green' },
  ];

  const acaiSizes = [
    { id: '300', label: '300ml', price: settings?.acai?.['300'] || 25.90, rules: '3 verdes + 1 laranjas', icon: <CupSoda /> },
    { id: '400', label: '400ml', price: settings?.acai?.['400'] || 30.90, rules: '3 verdes + 1 laranjas', icon: <CupSoda /> },
    { id: '500', label: '500ml', price: settings?.acai?.['500'] || 36.90, rules: '3 verdes + 1 laranjas', icon: <CupSoda /> },
    { id: '700', label: '700ml', price: settings?.acai?.['700'] || 44.90, rules: '3 verdes + 1 laranjas', icon: <CupSoda /> },
    { id: 'M500', label: 'M (500ml)', price: settings?.acai?.['M500'] || 39.90, rules: '3 verdes + 2 laranjas', icon: <Soup /> },
    { id: 'G800', label: 'G (800ml)', price: settings?.acai?.['G800'] || 48.90, rules: '3 verdes + 2 laranjas', icon: <Soup /> },
  ];

  const acaiOptions = {
    laranjas: ['Bolacha oreo triturada', 'Bombom Ouro branco', 'Bombom Sonho de valsa', 'Castanha de caju', 'Cereja', 'Disquete', 'Gotas de Chocolate'],
    verdes: ['Banana', 'Beijinho cremoso', 'Cobertura de Chocolate', 'Cobertura de Morango', 'Granola', 'Leite condensado', 'Leite em Pó']
  };

  const paidAddons = [
    { name: 'Creme de ninho', price: 5.20 },
    { name: 'Creme de Pistache', price: 5.78 },
    { name: 'Kinder Bueno', price: 6.36 },
    { name: 'Creme de Valsa', price: 5.20 },
    { name: 'Kit Kat', price: 5.78 },
    { name: 'Nutella', price: 5.78 }
  ];

  const milkshakeSizes = [
    { id: '300', label: '300ml', price: settings?.milkshake?.['300'] || 20.90 },
    { id: '400', label: '400ml', price: settings?.milkshake?.['400'] || 25.90 },
    { id: '500', label: '500ml', price: settings?.milkshake?.['500'] || 28.90 },
  ];

  const sundaeSizes = [
    { id: '500', label: '500ml', price: settings?.sundae?.['500'] || 24.90 },
    { id: '700', label: '700ml', price: settings?.sundae?.['700'] || 35.90 },
  ];

  const milkshakeOptions = [
    { name: 'Chantilly', price: 2.00 },
    { name: 'Creme de Ninho', price: 4.00 },
    { name: 'Nutella', price: 5.00 },
    { name: 'Ovomaltine', price: 3.50 }
  ];

  const renderScreen = () => {
    switch(currentScreen) {
      case 'home':
        return (
          <div className="flex flex-col items-center no-print bg-[#fff9f5] min-h-screen">
            <header className="relative w-full bg-amarena-dark-red pt-8 pb-12 px-6 shadow-[0_10px_30px_rgba(150,18,29,0.3)] mb-8 overflow-visible border-b border-white/5">
              <div className="flex items-start max-w-lg mx-auto relative z-30 w-full">
                <Logo />
                {/* Cart Button absolutely positioned near the awnings */}
                <button 
                  onClick={() => setCurrentScreen('checkout')}
                  className="absolute bottom-1 right-[8%] bg-amarena-dark-red p-4 rounded-full text-white hover:bg-amarena-red transition-all shadow-[0_8px_20px_rgba(0,0,0,0.3)] border-[3px] border-white/20 active:scale-90 z-50 flex items-center justify-center transform hover:-translate-y-1"
                >
                  <ShoppingCart size={24} />
                  {cart.length > 0 && (
                    <span className="absolute -top-1 -right-1 bg-amarena-green text-white text-[10px] font-bold w-6 h-6 flex items-center justify-center rounded-full border-2 border-amarena-dark-red shadow-lg animate-bounce">
                      {cart.length}
                    </span>
                  )}
                </button>
              </div>
              
              {/* Luxury Gloss Reflection Overlay */}
              <div className="absolute top-0 left-0 right-0 h-full bg-gradient-to-tr from-white/5 via-white/10 to-transparent pointer-events-none opacity-40" />
              
              {/* Toldo/Awning effect */}
              <Awning />
            </header>
            
            <div className="grid grid-cols-2 gap-5 w-full px-5 max-w-lg">
              {menuItems.map((item) => (
                <motion.button
                  key={item.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    if (item.id === 'whatsapp') {
                      window.open('https://wa.me/553599999999', '_blank'); // Replace with real number
                      return;
                    }
                    setCurrentScreen(item.id as typeof currentScreen);
                  }}
                  className={`${item.color} p-8 rounded-[32px] shadow-lg flex flex-col items-center justify-center gap-4 text-white transition-shadow hover:shadow-xl`}
                >
                  <div className="bg-white/20 p-4 rounded-3xl">
                    {React.cloneElement(item.icon as React.ReactElement, { size: 40 })}
                  </div>
                  <span className="font-bold text-xl tracking-tight">{item.label}</span>
                </motion.button>
              ))}
            </div>

            <div className="w-full px-5 pb-10 mt-10 space-y-3">
               <div className="bg-white p-5 rounded-3xl shadow-sm border border-stone-100 flex items-center gap-4">
                  <div className="bg-red-100 p-3 rounded-2xl text-amarena-red"><MapPin size={20} /></div>
                  <div>
                    <p className="font-bold text-stone-800 text-sm">Rua Dois de Novembro</p>
                    <p className="text-xs text-stone-400">Centro - Passos, MG</p>
                  </div>
               </div>
               <div className="bg-white p-5 rounded-3xl shadow-sm border border-stone-100 flex items-center gap-4">
                  <div className="bg-green-100 p-3 rounded-2xl text-amarena-green"><MessageCircle size={20} /></div>
                  <p className="font-bold text-stone-800 text-sm">Fale conosco no WhatsApp</p>
               </div>
               <div className="bg-white p-5 rounded-3xl shadow-sm border border-stone-100 flex items-center gap-4">
                  <div className="bg-pink-100 p-3 rounded-2xl text-pink-500"><Instagram size={20} /></div>
                  <p className="font-bold text-stone-800 text-sm">@amarena.passos</p>
               </div>
            </div>

            <div className="relative mt-10 mb-10 overflow-hidden rounded-full">
              {adminHoldProgress > 0 && (
                <div 
                  className="absolute inset-0 bg-amarena-red/10 transition-all duration-75"
                  style={{ width: `${adminHoldProgress}%` }}
                />
              )}
              <button 
                onMouseDown={startAdminHold}
                onMouseUp={cancelAdminHold}
                onMouseLeave={cancelAdminHold}
                onTouchStart={startAdminHold}
                onTouchEnd={cancelAdminHold}
                className="relative px-4 py-2 text-stone-200 text-[10px] font-medium uppercase tracking-[0.2em] transition-colors active:text-amarena-red/40 select-none"
              >
                © 2025 Amarena Sorvetes • Passos/MG
              </button>
            </div>
          </div>
        );

      case 'sorvete':
      case 'picole':
      case 'promos':
        return (
          <div className="px-6 py-10 animate-in fade-in slide-in-from-right-4 no-print">
            <div className="flex justify-between items-center mb-10">
              <button 
                onClick={() => setCurrentScreen('home')} 
                className="p-4 bg-white/50 backdrop-blur-md rounded-2xl text-stone-800 shadow-sm transition-all active:scale-95 border border-stone-100"
              >
                <ChevronLeft size={24} />
              </button>
              <h2 className="text-3xl font-display font-bold text-stone-800 uppercase tracking-tight">
                {menuItems.find(m => m.id === currentScreen)?.label}
              </h2>
              <div className="relative">
                <button 
                  onClick={() => setCurrentScreen('checkout')}
                  className="bg-amarena-red p-4 rounded-2xl text-white shadow-lg shadow-amarena-red/20 active:scale-95 transition-all"
                >
                  <ShoppingCart size={24} />
                  {cart.length > 0 && (
                    <span className="absolute -top-2 -right-2 bg-amarena-green text-white text-[10px] font-bold w-6 h-6 flex items-center justify-center rounded-full border-2 border-white shadow-sm">
                      {cart.length}
                    </span>
                  )}
                </button>
              </div>
            </div>

              <div className="grid grid-cols-1 gap-5">
                {products.filter(p => {
                  const matchesCategory = currentScreen === 'sorvete' 
                    ? (p.category === 'sorvete' || p.category === 'potes')
                    : (p.category === currentScreen);
                  return matchesCategory && (p.active ?? true);
                }).length === 0 ? (
                  <div className="py-20 text-center text-stone-400 bg-white/50 rounded-[40px] border border-dashed border-stone-200">
                    <Package size={48} className="mx-auto mb-4 opacity-10" />
                    Nenhum produto disponível nesta categoria no momento.
                  </div>
                ) : (
                  products.filter(p => {
                    const matchesCategory = currentScreen === 'sorvete' 
                      ? (p.category === 'sorvete' || p.category === 'potes')
                      : (p.category === currentScreen);
                    return matchesCategory && (p.active ?? true);
                  }).map(product => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={product.id} 
                    className="bg-white p-5 rounded-[32px] shadow-sm border border-stone-100 flex items-center justify-between gap-4 group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-20 h-20 bg-stone-50 rounded-[24px] overflow-hidden flex-shrink-0 border border-stone-50">
                        {product.image ? (
                          <img 
                            src={product.image} 
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                            alt={product.name} 
                            referrerPolicy="no-referrer" 
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-stone-200">
                            <IceCream size={32} />
                          </div>
                        )}
                      </div>
                      <div>
                        <h3 className="font-bold text-stone-800 text-lg leading-tight mb-1">{product.name}</h3>
                        <p className="text-amarena-red font-black text-xl">R$ {product.price.toFixed(2)}</p>
                      </div>
                    </div>
                    <Button 
                      variant="primary" 
                      className="w-14 h-14 !p-0 rounded-2xl shadow-xl shadow-amarena-red/20 active:scale-90"
                      onClick={() => {
                        setCart(prev => [...prev, { name: product.name, price: product.price, quantity: 1 }]);
                      }}
                    >
                      <ShoppingCart size={24} />
                    </Button>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        );

      case 'milkshake': {
        const currentSizes = milkshakeCategory === 'milkshake' ? milkshakeSizes : sundaeSizes;
        const currentOptions = milkshakeCategory === 'milkshake' 
          ? milkshakeOptions.map(o => ({ name: o.name, price: o.price }))
          : [
              ...acaiOptions.laranjas.map(o => ({ name: o, price: 0 })),
              ...acaiOptions.verdes.map(o => ({ name: o, price: 0 })),
              ...paidAddons.map(o => ({ name: o.name, price: o.price }))
            ];

        return (
          <div className="animate-in fade-in duration-500 no-print flex flex-col h-screen bg-white">
            <div className="bg-amarena-purple p-6 text-white flex flex-col gap-4 sticky top-0 z-50">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => { setCurrentScreen('home'); setSelectedMilkshakeSize(null); setMilkshakeFlavorInput(''); setMilkshakeAddons([]); }}
                  className="hover:bg-white/20 p-2 rounded-xl"
                >
                  <ChevronLeft size={24} />
                </button>
                <h2 className="text-xl font-bold tracking-tight text-center flex-1 pr-10">
                  {milkshakeCategory === 'milkshake' ? 'Milkshake' : 'Sundae'}
                </h2>
              </div>
              
              {/* Category Toggle */}
              <div className="flex bg-white/20 p-1 rounded-2xl">
                 <button 
                  onClick={() => { setMilkshakeCategory('milkshake'); setSelectedMilkshakeSize(null); setMilkshakeAddons([]); }}
                  className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${milkshakeCategory === 'milkshake' ? 'bg-white text-amarena-purple shadow-sm' : 'text-white'}`}
                 >
                   Milkshake
                 </button>
                 <button 
                  onClick={() => { setMilkshakeCategory('sundae'); setSelectedMilkshakeSize(null); setMilkshakeAddons([]); }}
                  className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${milkshakeCategory === 'sundae' ? 'bg-white text-amarena-purple shadow-sm' : 'text-white'}`}
                 >
                   Sundae
                 </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 pb-52 space-y-8">
              {/* Size Selection */}
              <div>
                <h3 className="text-sm font-bold text-stone-500 uppercase tracking-widest mb-4 pl-1">Escolha o Tamanho</h3>
                <div className="grid grid-cols-2 gap-4">
                  {currentSizes.map(size => (
                    <button
                      key={size.id}
                      onClick={() => setSelectedMilkshakeSize(size.id)}
                      className={`bg-white border-2 p-6 rounded-3xl text-center shadow-sm transition-all flex flex-col items-center gap-2 ${
                        selectedMilkshakeSize === size.id ? 'border-amarena-purple shadow-md' : 'border-stone-100'
                      }`}
                    >
                      <div className={`p-4 rounded-2xl ${selectedMilkshakeSize === size.id ? 'bg-amarena-purple text-white' : 'bg-stone-50 text-amarena-purple'}`}>
                        {milkshakeCategory === 'milkshake' ? <CupSoda size={32} /> : <Soup size={32} />}
                      </div>
                      <p className="font-bold text-xl text-stone-700">{size.label}</p>
                      <p className={`font-black text-lg ${selectedMilkshakeSize === size.id ? 'text-amarena-purple' : 'text-amarena-purple/60'}`}>
                        R$ {size.price.toFixed(2)}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Flavor Input */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-stone-500 uppercase tracking-widest pl-1">Digite o Sabor</label>
                <input 
                  type="text"
                  placeholder="Ex: Chocolate, Morango..."
                  value={milkshakeFlavorInput}
                  onChange={(e) => setMilkshakeFlavorInput(e.target.value)}
                  className="w-full p-5 rounded-2xl bg-stone-50 border-2 border-stone-100 focus:border-amarena-purple outline-none font-bold text-stone-800 transition-all"
                />
              </div>

              <section className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold text-stone-800">Adicionais (opcional)</h3>
                  <p className="text-xs text-stone-400 font-medium">Valores cobrados a parte</p>
                </div>
                
                <div className="space-y-3">
                  {currentOptions.map(opt => {
                    const isSelected = milkshakeAddons.includes(opt.name);
                    return (
                      <button
                        key={opt.name}
                        onClick={() => setMilkshakeAddons(prev => isSelected ? prev.filter(i => i !== opt.name) : [...prev, opt.name])}
                        className={`w-full p-5 rounded-2xl border-2 flex justify-between items-center transition-all bg-white ${
                          isSelected ? 'border-amarena-purple shadow-sm' : 'border-stone-100'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                           <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${isSelected ? 'border-amarena-purple bg-amarena-purple' : 'border-stone-200'}`}>
                              {isSelected && <Check size={14} className="text-white" />}
                           </div>
                           <span className="font-bold text-stone-700">{opt.name}</span>
                        </div>
                        {opt.price > 0 && <span className="font-black text-amarena-purple">+ R$ {opt.price.toFixed(2)}</span>}
                        {opt.price === 0 && <span className="text-[10px] font-bold text-amarena-green uppercase tracking-widest">Grátis</span>}
                      </button>
                    );
                  })}
                </div>
              </section>
            </div>

            <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t border-stone-100 shadow-[0_-10px_30px_rgba(0,0,0,0.05)] z-50">
              {(() => {
                const sizePrice = currentSizes.find(s => s.id === selectedMilkshakeSize)?.price || 0;
                const addonsPrice = milkshakeAddons.reduce((acc, name) => acc + (currentOptions.find(o => o.name === name)?.price || 0), 0);
                const total = sizePrice > 0 ? sizePrice + addonsPrice : 0;
                const canFinish = selectedMilkshakeSize && milkshakeFlavorInput.trim().length > 0;

                return (
                  <>
                    <div className="flex justify-between items-center mb-2">
                       <p className="text-xl font-bold text-amarena-purple">Total:</p>
                       <p className="text-3xl font-display font-black text-amarena-purple">R$ {total.toFixed(2)}</p>
                    </div>

                    <div className="text-center mb-4">
                       {!canFinish && (
                         <p className="text-xs font-bold text-red-500 animate-pulse">
                            Digite o sabor e escolha o tamanho
                         </p>
                       )}
                    </div>

                    <Button 
                      variant={canFinish ? "purple" : "outline"}
                      disabled={!canFinish}
                      className={`w-full py-5 text-lg uppercase font-black tracking-widest ${!canFinish ? 'opacity-30' : 'shadow-xl shadow-amarena-purple/20'}`}
                      onClick={() => {
                        const sizeObj = currentSizes.find(s => s.id === selectedMilkshakeSize);
                        setCart(prev => [...prev, {
                          name: `${milkshakeCategory === 'milkshake' ? 'Milkshake' : 'Sundae'} ${sizeObj?.label} - ${milkshakeFlavorInput} ${milkshakeAddons.length > 0 ? `(+ ${milkshakeAddons.join(', ')})` : ''}`,
                          price: total,
                          quantity: 1
                        }]);
                        setCurrentScreen('home');
                        setSelectedMilkshakeSize(null);
                        setMilkshakeFlavorInput('');
                        setMilkshakeAddons([]);
                      }}
                    >
                      <ShoppingCart size={20} className="mr-2" />
                      Adicionar ao Carrinho
                    </Button>
                  </>
                );
              })()}
            </div>
          </div>
        );
      }

      case 'acai':
        return (
          <div className="animate-in fade-in duration-500 no-print flex flex-col h-screen bg-white">
            <div className="bg-amarena-purple p-6 text-white flex items-center gap-4 sticky top-0 z-50">
              <button 
                onClick={() => { setCurrentScreen('home'); setSelectedSize(null); }}
                className="hover:bg-white/20 p-2 rounded-xl"
              >
                <ChevronLeft size={24} />
              </button>
              <h2 className="text-xl font-bold tracking-tight">Açaí</h2>
            </div>
            
            {!selectedSize ? (
              <div className="px-6 py-8 space-y-6 flex-1 overflow-y-auto">
                <h3 className="text-lg font-bold text-stone-800">Escolha o Tamanho</h3>
                <div className="grid grid-cols-2 gap-4">
                  {acaiSizes.map(size => (
                    <button
                      key={size.id}
                      onClick={() => setSelectedSize(size.id)}
                      className="bg-cream border-2 border-stone-50 p-6 rounded-[32px] text-center shadow-sm hover:border-amarena-purple transition-all active:scale-95 flex flex-col items-center gap-2"
                    >
                      <div className="text-amarena-purple mb-1">
                        {React.cloneElement(size.icon as React.ReactElement, { size: 32 })}
                      </div>
                      <p className="font-bold text-xl text-stone-700">{size.label}</p>
                      <p className="text-amarena-purple font-black text-lg">R$ {size.price.toFixed(2)}</p>
                      <p className="text-[10px] text-stone-400 font-bold uppercase tracking-wide">{size.rules}</p>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col overflow-hidden">
                 <div className="bg-amarena-purple/5 p-4 flex justify-between items-center border-b border-amarena-purple/10">
                    <div className="flex items-center gap-3">
                      <div className="bg-amarena-purple text-white p-2 rounded-xl">
                        {React.cloneElement(acaiSizes.find(s => s.id === selectedSize)?.icon as React.ReactElement, { size: 20 })}
                      </div>
                      <div>
                        <h4 className="font-bold text-amarena-purple">Açaí {acaiSizes.find(s => s.id === selectedSize)?.label}</h4>
                        <p className="text-[10px] text-amarena-purple/60 font-bold uppercase tracking-widest">
                           {acaiSizes.find(s => s.id === selectedSize)?.rules}
                        </p>
                      </div>
                    </div>
                    <button onClick={() => { setSelectedSize(null); setSelections([]); }} className="text-amarena-purple text-xs font-bold uppercase hover:underline">Trocar</button>
                 </div>

                 <div className="flex-1 overflow-y-auto p-4 space-y-8 pb-32">
                    {(() => {
                      const maxVerdes = 3;
                      const maxLaranjas = (selectedSize === 'M500' || selectedSize === 'G800') ? 2 : 1;
                      
                      const countLaranjas = selections.filter(s => acaiOptions.laranjas.includes(s)).length;
                      const countVerdes = selections.filter(s => acaiOptions.verdes.includes(s)).length;

                      return (
                        <div className="grid grid-cols-2 gap-4">
                           {/* Laranjas */}
                           <div>
                              <div className="bg-amarena-orange text-white p-3 rounded-t-2xl text-center text-[10px] font-black tracking-widest uppercase">
                                 Laranjas ({countLaranjas}/{maxLaranjas})
                              </div>
                              <div className="bg-amarena-orange/5 p-2 rounded-b-2xl space-y-2 border-x border-b border-amarena-orange/20">
                                 {acaiOptions.laranjas.map(opt => {
                                   const isSelected = selections.includes(opt);
                                   return (
                                     <button 
                                       key={opt}
                                       onClick={() => {
                                         if (!isSelected && countLaranjas >= maxLaranjas) return;
                                         setSelections(prev => isSelected ? prev.filter(i => i !== opt) : [...prev, opt]);
                                       }}
                                       className={`w-full p-3 rounded-xl text-[10px] font-bold text-left transition-all ${
                                         isSelected ? 'bg-amarena-orange text-white shadow-md' : 'bg-white text-amarena-orange border border-amarena-orange/30'
                                       } ${!isSelected && countLaranjas >= maxLaranjas ? 'opacity-30' : ''}`}
                                     >
                                       {opt}
                                     </button>
                                   );
                                 })}
                              </div>
                           </div>

                           {/* Verdes */}
                           <div>
                              <div className="bg-amarena-green text-white p-3 rounded-t-2xl text-center text-[10px] font-black tracking-widest uppercase">
                                 Verdes ({countVerdes}/{maxVerdes})
                              </div>
                              <div className="bg-amarena-green/5 p-2 rounded-b-2xl space-y-2 border-x border-b border-amarena-green/20">
                                 {acaiOptions.verdes.map(opt => {
                                   const isSelected = selections.includes(opt);
                                   return (
                                     <button 
                                       key={opt}
                                       onClick={() => {
                                         if (!isSelected && countVerdes >= maxVerdes) return;
                                         setSelections(prev => isSelected ? prev.filter(i => i !== opt) : [...prev, opt]);
                                       }}
                                       className={`w-full p-3 rounded-xl text-[10px] font-bold text-left transition-all ${
                                         isSelected ? 'bg-amarena-green text-white shadow-md' : 'bg-white text-amarena-green border border-amarena-green/30'
                                       } ${!isSelected && countVerdes >= maxVerdes ? 'opacity-30' : ''}`}
                                     >
                                       {opt}
                                     </button>
                                   );
                                 })}
                              </div>
                           </div>
                        </div>
                      );
                    })()}

                    <div className="space-y-4">
                       <h4 className="font-bold text-stone-800 border-l-4 border-amarena-purple pl-3 text-sm">Adicionais à Parte (Pagos)</h4>
                       <div className="grid grid-cols-2 gap-3">
                          {paidAddons.map(addon => {
                            const isSelected = selections.includes(addon.name);
                            return (
                              <button 
                                 key={addon.name}
                                 onClick={() => setSelections(prev => isSelected ? prev.filter(i => i !== addon.name) : [...prev, addon.name])}
                                 className={`p-4 rounded-2xl border transition-all text-left ${
                                   isSelected ? 'bg-amarena-orange text-white border-amarena-orange shadow-md' : 'bg-orange-50/50 border-amarena-orange/20 text-amarena-dark'
                                 }`}
                              >
                                 <p className={`font-bold text-xs ${isSelected ? 'text-white' : 'text-stone-800'}`}>{addon.name}</p>
                                 <p className={`font-black text-sm ${isSelected ? 'text-white/80' : 'text-amarena-orange'}`}>+R$ {addon.price.toFixed(2)}</p>
                              </button>
                            );
                          })}
                       </div>
                    </div>
                 </div>

                 {/* Selections Tracking */}
                 {(() => {
                   const sizeObj = acaiSizes.find(s => s.id === selectedSize);
                   const maxVerdes = 3;
                   const maxLaranjas = (selectedSize === 'M500' || selectedSize === 'G800') ? 2 : 1;
                   
                   const countLaranjas = selections.filter(s => acaiOptions.laranjas.includes(s)).length;
                   const countVerdes = selections.filter(s => acaiOptions.verdes.includes(s)).length;
                   
                   const selectedPaidAddons = selections.filter(s => paidAddons.find(a => a.name === s));
                   const paidTotal = selectedPaidAddons.reduce((acc, name) => acc + (paidAddons.find(a => a.name === name)?.price || 0), 0);
                   const finalPrice = (sizeObj?.price || 0) + paidTotal;

                   const faltamVerdes = Math.max(0, maxVerdes - countVerdes);
                   const faltamLaranjas = Math.max(0, maxLaranjas - countLaranjas);
                   const canFinish = faltamVerdes === 0 && faltamLaranjas === 0;

                   return (
                     <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t border-stone-100 shadow-[0_-10px_30px_rgba(0,0,0,0.05)] z-50">
                        <div className="flex justify-between items-center mb-4">
                           <p className="font-bold text-stone-400 uppercase tracking-widest text-xs">Total:</p>
                           <p className="text-3xl font-display font-black text-amarena-purple">R$ {finalPrice.toFixed(2)}</p>
                        </div>
                        
                        {!canFinish ? (
                          <div className="bg-orange-50 p-3 rounded-2xl text-center mb-4 border border-amarena-orange/10">
                             <p className="text-[10px] font-bold text-amarena-orange uppercase tracking-widest">
                                {faltamVerdes > 0 && `Faltam ${faltamVerdes} opções VERDES `}
                                {faltamLaranjas > 0 && `${faltamVerdes > 0 ? '• ' : ''}Faltam ${faltamLaranjas} opções LARANJAS`}
                             </p>
                          </div>
                        ) : (
                          <div className="bg-green-50 p-3 rounded-2xl text-center mb-4 border border-amarena-green/10">
                             <p className="text-[10px] font-bold text-amarena-green uppercase tracking-widest">
                                Seleção Completa!
                             </p>
                          </div>
                        )}

                        <Button 
                          variant={canFinish ? "purple" : "outline"}
                          disabled={!canFinish}
                          className={`w-full py-5 text-lg uppercase font-black tracking-widest ${!canFinish ? 'opacity-50 cursor-not-allowed' : 'shadow-xl shadow-amarena-purple/20'}`}
                          onClick={() => {
                            if (sizeObj) {
                              setCart(prev => [...prev, {
                                name: `Açaí ${sizeObj.label} (${selections.join(', ')})`,
                                price: finalPrice,
                                quantity: 1
                              }]);
                              setCurrentScreen('home'); // Go back to home after adding
                            }
                          }}
                        >
                          Adicionar ao Carrinho
                        </Button>
                     </div>
                   );
                 })()}
              </div>
            )}
          </div>
        );

      case 'admin':
        if (!isAdminLoggedIn) {
          return (
            <div className="px-6 py-20 min-h-screen flex flex-col items-center justify-center animate-in fade-in zoom-in-95 no-print relative overflow-hidden">
              {/* Login Background Accents */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl -mr-32 -mt-32" />
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-secondary/10 rounded-full blur-3xl -ml-32 -mb-32" />

              <div className="w-full max-w-md bg-white p-8 md:p-12 rounded-[48px] shadow-premium border border-amarena/5 relative z-10">
                <div className="flex flex-col items-center mb-8">
                  <Logo light={false} />
                  <div className="mt-8 bg-primary/5 px-4 py-2 rounded-full">
                    <p className="text-primary font-bold text-xs uppercase tracking-widest flex items-center gap-2">
                       <Settings size={14} className="animate-spin-slow" /> Painel Interno
                    </p>
                  </div>
                </div>

                <form onSubmit={handleAdminLogin} className="space-y-5">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-amarena/40 uppercase tracking-widest ml-1">Acesso do Operador</label>
                    <input 
                      type="text" 
                      value={adminUser}
                      onChange={e => setAdminUser(e.target.value)}
                      className="w-full p-5 bg-stone-50 border-none rounded-3xl outline-none focus:ring-2 focus:ring-primary/20 transition-all font-medium text-amarena" 
                      placeholder="Username"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-amarena/40 uppercase tracking-widest ml-1">Chave de Segurança</label>
                    <input 
                      type="password" 
                      value={adminPass}
                      onChange={e => setAdminPass(e.target.value)}
                      className="w-full p-5 bg-stone-50 border-none rounded-3xl outline-none focus:ring-2 focus:ring-primary/20 transition-all font-medium text-amarena" 
                      placeholder="••••••••"
                      required
                    />
                  </div>
                  <Button loading={loading} className="w-full py-5 rounded-3xl text-lg shadow-xl shadow-amarena-red/20 mt-6">
                    Autenticar Operação
                  </Button>
                </form>
                
                <button 
                  onClick={() => setCurrentScreen('home')}
                  className="w-full text-center mt-8 text-amarena/30 text-xs font-bold uppercase tracking-widest hover:text-amarena-red transition-colors"
                >
                  Voltar ao Terminal Inicial
                </button>
              </div>
            </div>
          );
        }

        return (
          <div className="h-screen flex flex-col md:flex-row bg-stone-50 no-print">
            {/* Sidebar for PC optimization */}
            <aside className="w-full md:w-64 bg-white border-r border-stone-100 p-6 flex-shrink-0">
              <div className="flex items-center gap-3 mb-10">
                <div className="bg-amarena-red p-2 rounded-xl text-white">
                  <IceCream size={24} />
                </div>
                <h1 className="font-display font-bold text-xl text-stone-800">Amarena Admin</h1>
              </div>

              <nav className="space-y-2">
                <button 
                  onClick={() => setAdminSection('dashboard')}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${adminSection === 'dashboard' ? 'bg-amarena-red text-white shadow-md shadow-amarena-red/20' : 'text-stone-500 hover:bg-stone-50'}`}
                >
                  <LayoutDashboard size={20} />
                  <span className="font-semibold">Início</span>
                </button>
                <button 
                  onClick={() => setAdminSection('orders')}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${adminSection === 'orders' ? 'bg-amarena-red text-white shadow-md shadow-amarena-red/20' : 'text-stone-500 hover:bg-stone-50'}`}
                >
                  <History size={20} />
                  <span className="font-semibold">Pedidos</span>
                </button>
                <button 
                  onClick={() => setAdminSection('products')}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${adminSection === 'products' ? 'bg-amarena-red text-white shadow-md shadow-amarena-red/20' : 'text-stone-500 hover:bg-stone-50'}`}
                >
                  <Package size={20} />
                  <span className="font-semibold">Produtos</span>
                </button>
                <button 
                  onClick={() => setAdminSection('addons')}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${adminSection === 'addons' ? 'bg-amarena-red text-white shadow-md shadow-amarena-red/20' : 'text-stone-500 hover:bg-stone-50'}`}
                >
                  <Settings size={20} />
                  <span className="font-semibold">Adicionais</span>
                </button>
                <button 
                  onClick={() => setAdminSection('settings')}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${adminSection === 'settings' ? 'bg-amarena-red text-white shadow-md shadow-amarena-red/20' : 'text-stone-500 hover:bg-stone-50'}`}
                >
                  <Sliders size={20} />
                  <span className="font-semibold">Configurações</span>
                </button>
              </nav>

              <div className="mt-auto pt-10">
                <button 
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 p-3 rounded-xl text-red-500 hover:bg-red-50 transition-all font-semibold"
                >
                  <LogOut size={20} />
                  Sair
                </button>
              </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 overflow-y-auto p-6 md:p-10">
              <div className="max-w-4xl mx-auto">
                {adminSection === 'dashboard' && (
                  <div className="animate-in fade-in slide-in-from-top-4 duration-500">
                    <h2 className="text-3xl font-display font-bold text-stone-800 mb-8 uppercase tracking-tight">Painel de Controle</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="bg-white p-8 rounded-[32px] shadow-sm border border-stone-100 flex flex-col items-center text-center">
                        <p className="text-sm font-bold text-stone-400 uppercase tracking-widest mb-1">Pedidos Pendentes</p>
                        <p className="text-5xl font-display font-bold text-amarena-red">{orders.filter(o => o.status === 'pending').length}</p>
                      </div>
                      <div className="bg-white p-8 rounded-[32px] shadow-sm border border-stone-100 flex flex-col items-center text-center">
                        <p className="text-sm font-bold text-stone-400 uppercase tracking-widest mb-1">Total de Produtos</p>
                        <p className="text-5xl font-display font-bold text-amarena-green">{products.length}</p>
                      </div>
                      <div className="bg-white p-8 rounded-[32px] shadow-sm border border-stone-100 flex flex-col items-center text-center">
                        <p className="text-sm font-bold text-stone-400 uppercase tracking-widest mb-1">Total Hoje</p>
                        <p className="text-5xl font-display font-bold text-amarena-purple">R$ {orders.filter(o => new Date(o.createdAt).getDate() === new Date().getDate()).reduce((acc, curr) => acc + curr.total, 0).toFixed(0)}</p>
                      </div>
                    </div>
                  </div>
                )}

                {adminSection === 'orders' && (
                  <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                    <div className="flex justify-between items-center mb-8">
                      <h2 className="text-3xl font-display font-bold text-stone-800 uppercase tracking-tight">Gerenciar Pedidos</h2>
                      <button onClick={fetchOrders} className="p-2 bg-stone-100 rounded-xl text-stone-500 hover:bg-stone-200 transition-colors">
                        <History size={18} />
                      </button>
                    </div>

                    <div className="space-y-4">
                      {orders.length === 0 ? (
                        <div className="py-20 text-center text-stone-400 bg-white rounded-3xl border border-dashed border-stone-200">Nenhum pedido recebido ainda.</div>
                      ) : (
                        orders.map(order => (
                          <div key={order.id} className="bg-white p-6 rounded-[32px] shadow-sm border border-stone-100 flex flex-col md:flex-row md:items-center justify-between gap-6">
                            <div>
                              <div className="flex items-center gap-3 mb-2">
                                <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${order.status === 'pending' ? 'bg-orange-100 text-orange-600' : 'bg-green-100 text-green-600'}`}>
                                  {order.status === 'pending' ? 'Pendente' : 'Finalizado'}
                                </span>
                                <span className="text-stone-400 text-xs font-medium">#{order.id.slice(-6)} • {new Date(order.createdAt).toLocaleTimeString('pt-BR')}</span>
                              </div>
                              <div className="space-y-1">
                                {order.items.map((it, idx) => (
                                  <p key={idx} className="text-stone-800 font-bold text-lg">{it.quantity}x {it.name}</p>
                                ))}
                              </div>
                              <p className="text-stone-400 text-sm mt-1 uppercase tracking-wider font-semibold">{order.paymentMethod} • R$ {order.total.toFixed(2)}</p>
                            </div>
                            <div className="flex gap-2">
                              {order.status === 'pending' && (
                                <button 
                                  onClick={async () => {
                                    await axios.patch(`/api/admin/orders/${order.id}`, { status: 'completed' }, {
                                      headers: { Authorization: `Bearer ${localStorage.getItem('amarena_admin_token')}` }
                                    });
                                    fetchOrders();
                                  }}
                                  className="flex-1 md:flex-none p-4 bg-green-500 text-white rounded-2xl hover:bg-green-600 transition-all font-bold flex items-center justify-center gap-2"
                                >
                                  <Check size={20} /> Concluir
                                </button>
                              )}
                              <button 
                                onClick={() => handlePrint(order)}
                                className="flex-1 md:flex-none p-4 bg-stone-800 text-white rounded-2xl hover:bg-black transition-all font-bold flex items-center justify-center gap-2"
                              >
                                <Printer size={20} /> Imprimir
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}

                {adminSection === 'addons' && (
                  <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                     <h2 className="text-3xl font-display font-bold text-stone-800 mb-8 uppercase tracking-tight">Gerenciar Adicionais</h2>
                     <div className="bg-white rounded-[32px] border border-stone-100 overflow-hidden shadow-sm">
                        <table className="w-full text-left">
                           <thead className="bg-stone-50 border-b border-stone-100 text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                              <tr>
                                 <th className="px-6 py-4">Adicional</th>
                                 <th className="px-6 py-4">Preço</th>
                                 <th className="px-6 py-4 text-right">Ações</th>
                              </tr>
                           </thead>
                           <tbody className="divide-y divide-stone-50">
                              {products.filter(p => p.category === 'addon').map(p => (
                                 <tr key={p.id} className="hover:bg-stone-50/50 transition-colors">
                                    <td className="px-6 py-4 font-bold text-stone-800">{p.name}</td>
                                    <td className="px-6 py-4 font-bold text-stone-700">R$ {p.price.toFixed(2)}</td>
                                    <td className="px-6 py-4 text-right">
                                       <button 
                                         onClick={() => { setEditingProduct(p); setAdminSection('products'); }}
                                         className="p-2 bg-stone-100 text-stone-500 hover:text-amarena-green rounded-lg transition-all"
                                       >
                                          <Edit size={16} />
                                       </button>
                                    </td>
                                 </tr>
                              ))}
                           </tbody>
                        </table>
                     </div>
                  </div>
                )}
                {adminSection === 'settings' && (
                   <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                      <h2 className="text-3xl font-display font-bold text-stone-800 mb-8 uppercase tracking-tight">Configurações</h2>
                      <div className="bg-white p-8 rounded-[32px] shadow-sm border border-stone-100">
                        <h3 className="font-bold text-stone-800 mb-6">Preços de Açaí</h3>
                        <div className="grid grid-cols-2 gap-4">
                           {['300', '400', '500', '700', 'M500', 'G800'].map(id => (
                             <div key={id} className="space-y-1">
                                <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">{id}ml / {id === 'M500' ? 'M' : id === 'G800' ? 'G' : ''}</label>
                                <input 
                                  type="number"
                                  className="w-full p-3 bg-stone-50 rounded-xl outline-none"
                                  value={settings?.acai?.[id] || ''}
                                  onChange={e => setSettings({...settings, acai: {...settings?.acai, [id]: parseFloat(e.target.value)}})}
                                />
                             </div>
                           ))}
                        </div>

                        <h3 className="font-bold text-stone-800 mb-6 mt-8">Preços de Milkshake</h3>
                         <div className="grid grid-cols-2 gap-4">
                           {['300', '400', '500'].map(id => (
                             <div key={id} className="space-y-1">
                                <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">{id}ml</label>
                                <input 
                                  type="number"
                                  className="w-full p-3 bg-stone-50 rounded-xl outline-none"
                                  value={settings?.milkshake?.[id] || ''}
                                  onChange={e => setSettings({...settings, milkshake: {...settings?.milkshake, [id]: parseFloat(e.target.value)}})}
                                />
                             </div>
                           ))}
                        </div>
                        
                        <h3 className="font-bold text-stone-800 mb-6 mt-8">Preços de Sundae</h3>
                         <div className="grid grid-cols-2 gap-4">
                           {['500', '700'].map(id => (
                             <div key={id} className="space-y-1">
                                <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">{id}ml</label>
                                <input 
                                  type="number"
                                  className="w-full p-3 bg-stone-50 rounded-xl outline-none"
                                  value={settings?.sundae?.[id] || ''}
                                  onChange={e => setSettings({...settings, sundae: {...settings?.sundae, [id]: parseFloat(e.target.value)}})}
                                />
                             </div>
                           ))}
                        </div>

                        {/* Gerenciamento de Adicionais por Categoria */}
                        <h3 className="font-bold text-stone-800 mb-6 mt-10 border-t pt-8">Adicionais por Categoria</h3>
                        <div className="space-y-6">
                          {(['acai', 'milkshake', 'sundae'] as const).map(cat => (
                            <div key={cat}>
                              <label className="text-xs font-bold text-stone-500 uppercase">{cat === 'acai' ? 'Açaí' : cat === 'milkshake' ? 'Milkshake' : 'Sundae'}</label>
                              <div className="mt-2 text-sm text-stone-600 bg-stone-50 p-4 rounded-xl">
                                Selecione os adicionais:
                                <div className="grid grid-cols-2 gap-2 mt-2">
                                  {products.filter(p => p.category === 'addon').map(addon => (
                                    <label key={addon.id} className="flex items-center gap-2">
                                      <input 
                                        type="checkbox"
                                        checked={(settings?.[`${cat}Addons` as keyof AppSettings] as string[] || []).includes(addon.name)}
                                        onChange={e => {
                                          const prev = (settings?.[`${cat}Addons` as keyof AppSettings] as string[] || []);
                                          const next = e.target.checked 
                                            ? [...prev, addon.name]
                                            : prev.filter(n => n !== addon.name);
                                          setSettings({...settings, [`${cat}Addons`]: next});
                                        }}
                                      />
                                      {addon.name}
                                    </label>
                                  ))}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        <button 
                          onClick={async () => {
                            const token = localStorage.getItem('amarena_admin_token');
                            try {
                              await axios.put('/api/settings', settings, { 
                                headers: { Authorization: `Bearer ${token}` } 
                              });
                              alert('Configurações salvas com sucesso!');
                              await fetchSettings(); // Refresh UI
                            } catch (error) {
                              console.error("Save error:", error);
                              alert('Erro ao salvar configurações.');
                            }
                          }}
                          className="mt-6 w-full p-4 bg-amarena-red text-white font-bold rounded-xl"
                        >
                          Salvar Configurações
                        </button>
                      </div>
                   </div>
                )}
                {adminSection === 'products' && (
                  <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                    <h2 className="text-3xl font-display font-bold text-stone-800 mb-8 uppercase tracking-tight">Gerenciar Produtos</h2>
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                       <div className="lg:col-span-4 bg-white p-6 rounded-[32px] shadow-sm border border-stone-100 h-fit sticky top-6">
                          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                             {editingProduct?.id ? <Edit size={20} className="text-amarena-red" /> : <Package size={20} className="text-amarena-red" />}
                             {editingProduct?.id ? 'Editar Produto' : 'Novo Produto'}
                          </h3>
                          <form onSubmit={handleProductSubmit} className="space-y-4">
                            <div className="space-y-1">
                               <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest ml-1">Nome do Produto</label>
                               <input 
                                 type="text" 
                                 placeholder="Ex: Sorvete de Morango" 
                                 value={editingProduct?.name || ''}
                                 onChange={e => setEditingProduct(prev => ({ ...prev, name: e.target.value }))}
                                 className="w-full p-4 bg-stone-50 rounded-2xl outline-none focus:ring-2 focus:ring-primary/20 transition-all font-medium" 
                                 required
                               />
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                               <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest ml-1">Categoria</label>
                                  <select 
                                    value={editingProduct?.category || 'sorvete'}
                                    onChange={e => setEditingProduct(prev => ({ ...prev, category: e.target.value as Product['category'] }))}
                                    className="w-full p-4 bg-stone-50 rounded-2xl outline-none focus:ring-2 focus:ring-primary/20 transition-all font-medium appearance-none"
                                  >
                                    {productCategories.map(cat => (
                                      <option key={cat} value={cat}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</option>
                                    ))}
                                  </select>
                               </div>
                               <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest ml-1">Preço (R$)</label>
                                  <input 
                                    type="number" 
                                    step="0.01"
                                    placeholder="0,00" 
                                    value={editingProduct?.price || ''}
                                    onChange={e => setEditingProduct(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
                                    className="w-full p-4 bg-stone-50 rounded-2xl outline-none focus:ring-2 focus:ring-primary/20 transition-all font-medium" 
                                    required
                                  />
                               </div>
                            </div>

                            <div className="space-y-1">
                               <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest ml-1">Imagem do Produto (Upload ou Drag & Drop)</label>
                               <div 
                                 onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                                 onDragLeave={() => setIsDragging(false)}
                                 onDrop={(e) => {
                                   e.preventDefault();
                                   setIsDragging(false);
                                   const file = e.dataTransfer.files[0];
                                   if (file && file.type.startsWith('image/')) handleImageUpload(file);
                                 }}
                                 className={`relative group w-full h-40 rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center gap-2 overflow-hidden ${isDragging ? 'border-amarena-red bg-amarena-red/5' : 'border-stone-200 bg-stone-50 hover:bg-stone-100'}`}
                               >
                                 {editingProduct?.image ? (
                                   <>
                                     <img src={editingProduct.image} className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-20 transition-opacity" referrerPolicy="no-referrer" />
                                     <div className="relative flex flex-col items-center gap-1 z-10">
                                        <Check size={24} className="text-amarena-red bg-white rounded-full p-1" />
                                        <p className="text-[10px] font-bold text-stone-600">Imagem Carregada</p>
                                        <p className="text-[9px] text-stone-400">Solte outra para trocar</p>
                                     </div>
                                   </>
                                 ) : (
                                   <>
                                     <div className="p-3 bg-white rounded-xl shadow-sm text-stone-400 group-hover:text-amarena-red transition-colors">
                                        <Upload size={20} />
                                     </div>
                                     <div className="text-center">
                                       <p className="text-[10px] font-bold text-stone-500">Arraste a imagem aqui</p>
                                       <p className="text-[9px] text-stone-400">ou clique para selecionar</p>
                                     </div>
                                   </>
                                 )}
                                 <input 
                                   type="file" 
                                   accept="image/*"
                                   className="absolute inset-0 opacity-0 cursor-pointer"
                                   onChange={(e) => {
                                     const file = e.target.files?.[0];
                                     if (file) handleImageUpload(file);
                                   }}
                                 />
                               </div>
                             </div>

                             <div className="flex items-center gap-3 p-4 bg-stone-50 rounded-2xl">
                               <button
                                 type="button"
                                 onClick={() => setEditingProduct(prev => ({ ...prev, active: !(prev?.active ?? true) }))}
                                 className={`w-12 h-6 rounded-full transition-all relative ${ (editingProduct?.active ?? true) ? 'bg-amarena-green' : 'bg-stone-300' }`}
                               >
                                 <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${ (editingProduct?.active ?? true) ? 'left-7' : 'left-1' }`} />
                               </button>
                               <span className="text-xs font-bold text-stone-600 uppercase">
                                 { (editingProduct?.active ?? true) ? 'Produto Disponível' : 'Produto de Temporada (Oculto)' }
                               </span>
                             </div>

                             <div className="pt-2 flex gap-3">
                               <Button 
                                 loading={loading} 
                                 className="flex-1 h-14 shadow-[0_10px_25px_-5px_rgba(150,18,29,0.4)] text-base font-black tracking-wide"
                               >
                                  {editingProduct?.id ? 'Salvar Alterações' : 'Criar Produto'}
                               </Button>
                               {editingProduct && (
                                 <button 
                                   type="button"
                                   onClick={() => setEditingProduct(null)}
                                   className="w-14 h-14 bg-stone-100 text-stone-400 rounded-2xl hover:bg-stone-200 transition-all flex items-center justify-center shadow-inner"
                                 >
                                   <X size={24} />
                                 </button>
                               )}
                            </div>
                          </form>
                       </div>

                       <div className="lg:col-span-8 space-y-4">
                          <div className="bg-white rounded-[32px] border border-stone-100 overflow-hidden">
                             <table className="w-full text-left">
                                <thead className="bg-stone-50 border-b border-stone-100 text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                                   <tr>
                                      <th className="px-6 py-4">Produto</th>
                                      <th className="px-6 py-4">Categoria</th>
                                      <th className="px-6 py-4">Preço</th>
                                       <th className="px-6 py-4">Status</th>
                                      <th className="px-6 py-4 text-right">Ações</th>
                                   </tr>
                                </thead>
                                <tbody className="divide-y divide-stone-50">
                                   {products.length === 0 ? (
                                     <tr>
                                        <td colSpan={5} className="px-6 py-20 text-center text-stone-400 italic">Nenhum produto cadastrado.</td>
                                     </tr>
                                   ) : (
                                     products.map(p => (
                                       <tr key={p.id} className="hover:bg-stone-50/50 transition-colors group">
                                          <td className="px-6 py-4">
                                             <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 bg-stone-100 rounded-xl overflow-hidden flex-shrink-0">
                                                   {p.image ? (
                                                     <img src={p.image} className="w-full h-full object-cover" alt={p.name} referrerPolicy="no-referrer" />
                                                   ) : (
                                                     <div className="w-full h-full flex items-center justify-center text-stone-300">
                                                        <Package size={16} />
                                                     </div>
                                                   )}
                                                </div>
                                                <span className="font-bold text-stone-800">{p.name}</span>
                                             </div>
                                          </td>
                                          <td className="px-6 py-4">
                                            <span className="px-2 py-1 bg-stone-100 rounded-lg text-[10px] font-bold text-stone-500 uppercase tracking-wider">
                                               {p.category}
                                            </span>
                                          </td>
                                          <td className="px-6 py-4 font-bold text-stone-700">R$ {p.price.toFixed(2)}</td>
                                           <td className="px-6 py-4">
                                              <button 
                                                onClick={() => {
                                                  const activeState = !(p.active ?? true);
                                                  const token = localStorage.getItem('amarena_admin_token');
                                                  axios.put(`/api/products/${p.id}`, { ...p, active: activeState }, {
                                                    headers: { Authorization: `Bearer ${token}` }
                                                  }).then(fetchProducts);
                                                }}
                                                className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition-all border shadow-sm ${ (p.active ?? true) ? 'bg-green-50 text-amarena-green border-green-100 hover:bg-green-100' : 'bg-red-50 text-red-500 border-red-100 hover:bg-red-100' }`}
                                              >
                                                { (p.active ?? true) ? 'Disponível' : 'Indisponível' }
                                              </button>
                                           </td>
                                          <td className="px-6 py-4 text-right">
                                             <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button 
                                                  onClick={() => setEditingProduct(p)}
                                                  className="w-10 h-10 flex items-center justify-center bg-stone-100 text-stone-500 hover:text-amarena-green hover:bg-green-50 rounded-xl transition-all shadow-sm"
                                                >
                                                  <Edit size={16} />
                                                </button>
                                                <button 
                                                  onClick={() => handleDeleteProduct(p.id)}
                                                  className="w-10 h-10 flex items-center justify-center bg-stone-100 text-stone-500 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all shadow-sm"
                                                >
                                                  <Trash2 size={16} />
                                                </button>
                                             </div>
                                          </td>
                                       </tr>
                                     ))
                                   )}
                                </tbody>
                             </table>
                          </div>
                       </div>
                    </div>
                  </div>
                )}
               </div>
            </main>
          </div>
        );

      case 'checkout': {
        const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
        const pixKey = "45.057.040/0001-08";

        const finishOrder = async (method: string) => {
          try {
            setLoading(true);
            const res = await axios.post('/api/orders', {
              items: cart,
              total: total,
              paymentMethod: method
            });
            setLastOrderId(res.data.id);
            setCurrentScreen('success');
            setCart([]);
            setSelectedSize(null);
            setSelections([]);
          } catch {
            alert("Erro ao enviar pedido.");
          } finally {
            setLoading(false);
          }
        };

        const handleCardPayment = async () => {
          try {
            setLoading(true);
            const res = await axios.post('/api/payment/create-preference', {
              items: cart,
              external_reference: `Order_${Date.now()}`
            });
            window.location.href = res.data.init_point;
          } catch {
            console.error("Payment error");
            alert("Erro ao iniciar pagamento.");
          } finally {
            setLoading(false);
          }
        };

        return (
          <div className="px-6 py-10 animate-in fade-in zoom-in-95 duration-500 no-print">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-display font-bold text-stone-800 uppercase tracking-tight">Finalizar</h2>
              <button onClick={() => setCurrentScreen('home')} className="p-2 bg-stone-100 rounded-xl">
                <X />
              </button>
            </div>

            <div className="bg-white rounded-[32px] p-6 shadow-sm border border-stone-100 mb-8">
              <div className="flex items-center gap-3 mb-4">
                <ShoppingBag className="text-primary" />
                <h3 className="font-bold text-stone-800">Seu Pedido</h3>
              </div>
              {cart.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center py-2 border-b border-stone-50 last:border-0 grow">
                  <span className="text-stone-600 font-medium">{item.name}</span>
                  <span className="font-bold text-stone-800 whitespace-nowrap ml-4">R$ {item.price.toFixed(2)}</span>
                </div>
              ))}
              <div className="mt-4 pt-4 border-t-2 border-stone-100 flex justify-between items-center">
                 <span className="text-stone-400 font-bold uppercase text-[10px] tracking-widest">Total Geral</span>
                 <span className="text-2xl font-display font-bold text-primary">R$ {total.toFixed(2)}</span>
              </div>
            </div>

            <h3 className="text-xl font-display font-bold text-stone-800 mb-4 px-2">Pagamento</h3>
            <div className="space-y-3">
              <button 
                onClick={() => setPaymentMethod('card')}
                className={`w-full p-6 rounded-3xl border-2 transition-all flex items-center gap-4 ${paymentMethod === 'card' ? 'border-primary bg-primary/5' : 'border-stone-100 bg-white'}`}
              >
                <div className={`p-3 rounded-2xl ${paymentMethod === 'card' ? 'bg-primary text-white' : 'bg-stone-100 text-stone-400'}`}>
                  <CreditCard size={24} />
                </div>
                <div className="text-left">
                  <p className="font-bold text-stone-800">Cartão de Crédito</p>
                  <p className="text-xs text-stone-400">Via Mercado Pago</p>
                </div>
              </button>

              <button 
                onClick={() => setPaymentMethod('pix')}
                className={`w-full p-6 rounded-3xl border-2 transition-all flex items-center gap-4 ${paymentMethod === 'pix' ? 'border-secondary bg-secondary/5' : 'border-stone-100 bg-white'}`}
              >
                <div className={`p-3 rounded-2xl ${paymentMethod === 'pix' ? 'bg-secondary text-white' : 'bg-stone-100 text-stone-400'}`}>
                  <QrCode size={24} />
                </div>
                <div className="text-left">
                  <p className="font-bold text-stone-800">PIX (Chave CNPJ)</p>
                  <p className="text-xs text-stone-400">Transferência Manual</p>
                </div>
              </button>
            </div>

            <div className="mt-8">
              {paymentMethod === 'pix' && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-3xl p-6 border-2 border-secondary/20 mb-6 text-center">
                  <p className="text-stone-500 text-sm mb-3 font-medium">Chave PIX CNPJ:</p>
                  <div className="bg-stone-50 p-4 rounded-2xl font-mono font-bold text-stone-800 break-all mb-4 flex justify-between items-center text-xs">
                    {pixKey}
                    <button onClick={() => { navigator.clipboard.writeText(pixKey); setPixCopied(true); setTimeout(()=>setPixCopied(false), 2000); }} className="text-secondary p-2">
                      {pixCopied ? <Check size={18} /> : <Copy size={18} />}
                    </button>
                  </div>
                  <p className="text-[10px] text-stone-400 leading-tight">Ao clicar em confirmar, seu pedido será enviado para nossa cozinha. O pagamento deve ser feito agora.</p>
                  <Button variant="secondary" className="w-full mt-6 py-4 text-lg" onClick={() => finishOrder('PIX Manual')}>Enviar Pedido via PIX</Button>
                </motion.div>
              )}

              {paymentMethod === 'card' && (
                <Button loading={loading} onClick={handleCardPayment} className="w-full py-5 text-xl shadow-xl shadow-primary/20">Finalizar com Cartão</Button>
              )}
            </div>
          </div>
        );
      }

      case 'success':
        return (
          <div className="px-6 py-20 flex flex-col items-center justify-center text-center animate-in zoom-in-95 duration-500 no-print">
            <div className="bg-green-100 p-8 rounded-full mb-8 text-green-500 shadow-inner">
              <Check size={64} />
            </div>
            <h2 className="text-3xl font-display font-bold text-stone-800 mb-4 uppercase tracking-tight">Pedido Recebido!</h2>
            <p className="text-stone-500 mb-10 max-w-xs">Nossa equipe já está preparando sua delícia. Você será notificado quando estiver pronto.</p>
            <div className="bg-stone-100 px-6 py-3 rounded-2xl mb-8">
               <p className="text-xs font-bold text-stone-400 uppercase tracking-widest">Senha do Pedido</p>
               <p className="text-2xl font-display font-bold text-stone-800">{String(lastOrderId).slice(-4).toUpperCase()}</p>
            </div>
            <Button onClick={() => setCurrentScreen('home')} variant="outline" className="w-full">Voltar ao Menu</Button>
          </div>
        );

      default:
        return (
          <div className="px-6 py-20 flex flex-col items-center justify-center text-center no-print">
            <div className="bg-stone-100 p-8 rounded-full mb-6 text-stone-400">
              <IceCream size={48} />
            </div>
            <h2 className="text-2xl font-bold text-stone-800 mb-2 uppercase tracking-tight">Em Breve</h2>
            <p className="text-stone-500 mb-8">Esta seção está sendo preparada.</p>
            <Button onClick={() => setCurrentScreen('home')} variant="outline">Voltar</Button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-cream flex items-center justify-center font-sans selection:bg-primary/20 selection:text-primary">
      {/* Background Decorative Pattern */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] overflow-hidden no-print">
        <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-primary blur-3xl" />
        <div className="absolute top-1/2 -right-48 w-[600px] h-[600px] rounded-full bg-secondary blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-80 h-80 rounded-full bg-accent blur-3xl opacity-50" />
      </div>

      {/* Actual App Container */}
      <div className={`w-full ${currentScreen === 'admin' ? 'h-screen' : 'max-w-2xl min-h-screen relative'} bg-cream/50 backdrop-blur-[2px] shadow-2xl relative overflow-x-hidden transition-all duration-500 border-x border-amarena/5`}>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen + (isAdminLoggedIn ? adminSection : '')}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="h-full"
          >
            {renderScreen()}
          </motion.div>
        </AnimatePresence>

        {/* Footer Branding (Hidden in Admin and Print) */}
        {!['admin', 'checkout', 'success'].includes(currentScreen) && (
          <footer className="py-12 flex flex-col items-center opacity-30 select-none pointer-events-none no-print">
            <Logo />
            <div className="mt-4 flex gap-4 text-primary">
              <IceCream size={16} />
              <IceCream size={16} />
              <IceCream size={16} />
            </div>
          </footer>
        )}
      </div>

      {/* Actual Hidden Ticket for Browser Printing */}
      <OrderTicket order={printOrder} />
    </div>
  );
}
