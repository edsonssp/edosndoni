import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { MongoClient, ObjectId, Db } from "mongodb";
import { MercadoPagoConfig, Preference } from "mercadopago";
import jwt from "jsonwebtoken";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// --- Environment Variables ---
const MONGO_URL = process.env.MONGO_URL;
const DB_NAME = process.env.DB_NAME || "amarena_db";
const MP_ACCESS_TOKEN = process.env.MERCADO_PAGO_ACCESS_TOKEN;
const JWT_SECRET = process.env.JWT_SECRET || "amarena_fallback_secret_2025";
const ADMIN_USER = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASS = process.env.ADMIN_PASSWORD || "admin123";

// --- Lazy Initialization of MongoDB ---
let dbClient: MongoClient | null = null;
let database: Db | null = null;

async function getDb() {
  if (!database) {
    if (!MONGO_URL) {
      throw new Error("MONGO_URL environment variable is not defined");
    }
    dbClient = new MongoClient(MONGO_URL);
    await dbClient.connect();
    database = dbClient.db(DB_NAME);
    console.log(`Connected to MongoDB: ${DB_NAME}`);
  }
  return database;
}

// --- Mercado Pago Setup ---
let mpClient: MercadoPagoConfig | null = null;

function getMpClient() {
  if (!mpClient) {
    if (!MP_ACCESS_TOKEN) {
      throw new Error("MERCADO_PAGO_ACCESS_TOKEN environment variable is not defined");
    }
    mpClient = new MercadoPagoConfig({ accessToken: MP_ACCESS_TOKEN });
  }
  return mpClient;
}

// --- Middleware ---
const authenticateAdmin = (req: express.Request & { user?: { username: string; role: string } }, res: express.Response, next: express.NextFunction) => {
  const token = req.headers["authorization"]?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { username: string; role: string };
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ limit: "10mb" }));

  // --- API Routes ---

  app.get("/api/health", async (_req, res) => {
    try {
      const db = await getDb();
      await db.command({ ping: 1 });
      res.json({ status: "ok", database: "connected", message: "Amarena Backend is operational" });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(500).json({ status: "error", error: message });
    }
  });

  // Auth
  app.post("/api/admin/login", async (req, res) => {
    const { username, password } = req.body;
    if (username === ADMIN_USER && password === ADMIN_PASS) {
      const token = jwt.sign({ username, role: "admin" }, JWT_SECRET, { expiresIn: "7d" });
      return res.json({ token, username });
    }
    res.status(401).json({ error: "Credenciais inválidas" });
  });

  // Products
  app.get("/api/products", async (req, res) => {
    try {
      const db = await getDb();
      const products = await db.collection("products").find().toArray();
      res.json(products.map(p => ({ ...p, id: p._id.toString() })));
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  app.post("/api/products", authenticateAdmin, async (req, res) => {
    try {
      const db = await getDb();
      const { name, category, price, description, image, active } = req.body;
      const result = await db.collection("products").insertOne({ 
        name, 
        category, 
        price: parseFloat(price), 
        description, 
        image,
        active: active !== undefined ? active : true,
        createdAt: new Date() 
      });
      res.status(201).json({ id: result.insertedId });
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  app.put("/api/products/:id", authenticateAdmin, async (req, res) => {
    try {
      const db = await getDb();
      const { name, category, price, description, image, active } = req.body;
      await db.collection("products").updateOne(
        { _id: new ObjectId(req.params.id) },
        { 
          $set: { 
            name, 
            category, 
            price: parseFloat(price), 
            description, 
            image,
            active: active !== undefined ? active : true,
            updatedAt: new Date() 
          } 
        }
      );
      res.json({ message: "Produto atualizado" });
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  app.delete("/api/products/:id", authenticateAdmin, async (req, res) => {
    try {
      const db = await getDb();
      await db.collection("products").deleteOne({ _id: new ObjectId(req.params.id) });
      res.json({ message: "Produto removido" });
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  // Orders
  app.post("/api/orders", async (req, res) => {
    try {
      const db = await getDb();
      const order = { ...req.body, status: "pending", createdAt: new Date() };
      const result = await db.collection("orders").insertOne(order);
      res.status(201).json({ id: result.insertedId, ...order });
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  app.get("/api/admin/orders", authenticateAdmin, async (req, res) => {
    try {
      const db = await getDb();
      const orders = await db.collection("orders").find().sort({ createdAt: -1 }).toArray();
      res.json(orders.map(o => ({ ...o, id: o._id.toString() })));
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  app.patch("/api/admin/orders/:id", authenticateAdmin, async (req, res) => {
    try {
      const db = await getDb();
      await db.collection("orders").updateOne(
        { _id: new ObjectId(req.params.id) },
        { $set: { status: req.body.status, updatedAt: new Date() } }
      );
      res.json({ message: "Status atualizado" });
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  // Settings
  app.get("/api/settings", async (req, res) => {
    try {
      const db = await getDb();
      console.log("Fetching settings from DB...");
      const settings = await db.collection("settings").findOne({ _id: new ObjectId("000000000000000000000001") });
      console.log("Settings found:", settings);
      if (settings) {
        const { _id, ...rest } = settings;
        res.json(rest);
      } else {
        res.json({});
      }
    } catch (err: unknown) {
      console.error("Error fetching settings:", err);
      res.status(500).json({ error: String(err) });
    }
  });

  app.put("/api/settings", authenticateAdmin, async (req, res) => {
    try {
      const db = await getDb();
      const { _id, ...data } = req.body;
      await db.collection("settings").updateOne(
        { _id: new ObjectId("000000000000000000000001") },
        { $set: data },
        { upsert: true }
      );
      res.json({ message: "Configurações salvas" });
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  // Mercado Pago
  app.post("/api/payment/create-preference", async (req, res) => {
    try {
      const { items, external_reference } = req.body;
      const client = getMpClient();
      const preference = new Preference(client);
      
      const response = await preference.create({
        body: {
          items: items.map((item: { name: string; quantity: number; price: number }) => ({
            title: item.name,
            quantity: item.quantity,
            unit_price: item.price,
            currency_id: "BRL"
          })),
          external_reference,
          back_urls: {
            success: `${process.env.APP_URL}/success`,
            failure: `${process.env.APP_URL}/failure`,
            pending: `${process.env.APP_URL}/pending`
          },
          auto_return: "approved",
          payment_methods: {
            excluded_payment_types: [{ id: "ticket" }, { id: "bank_transfer" }],
            installments: 12
          }
        }
      });
      res.json({ id: response.id, init_point: response.init_point });
    } catch (err: unknown) {
      res.status(500).json({ error: String(err) });
    }
  });

  // Vite
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => res.sendFile(path.join(distPath, "index.html")));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
